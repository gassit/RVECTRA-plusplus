import path from "path";
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: 'standalone',
  outputFileTracingRoot: path.join(__dirname),
  serverExternalPackages: [
    '@antv/g6',
    '@prisma/client',
    '@prisma/adapter-libsql',
    '@libsql/client',
  ],
  allowedDevOrigins: [
    'preview-chat-3688199d-1319-4584-8f20-3a103c2e0f67.space.z.ai',
    '*.space.z.ai',
  ],
};

export default nextConfig;
