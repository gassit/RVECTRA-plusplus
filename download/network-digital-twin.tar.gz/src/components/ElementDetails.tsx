'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { X, Zap, Gauge, Settings, AlertTriangle } from 'lucide-react';
import type { GraphNode } from '@/types';

interface ElementDetailsProps {
  node: GraphNode | null;
  onClose?: () => void;
}

const TYPE_NAMES: Record<string, string> = {
  SOURCE: 'Источник',
  CABINET: 'Шкаф',
  LOAD: 'Нагрузка',
  BREAKER: 'Выключатель',
  BUS: 'Шина',
  METER: 'Счётчик',
};

const TYPE_COLORS: Record<string, string> = {
  SOURCE: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300',
  CABINET: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
  LOAD: 'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300',
  BREAKER: 'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300',
  BUS: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
  METER: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900 dark:text-cyan-300',
};

export default function ElementDetails({ node, onClose }: ElementDetailsProps) {
  if (!node) return null;

  const mainDevice = node.devices?.[0];

  return (
    <Card className="shadow-lg border-slate-200 dark:border-slate-700 bg-white/95 dark:bg-slate-800/95 backdrop-blur">
      <CardHeader className="pb-2 pt-3 px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Badge className={TYPE_COLORS[node.type] || 'bg-slate-100 text-slate-700'}>
              {TYPE_NAMES[node.type] || node.type}
            </Badge>
            <CardTitle className="text-sm font-medium">{node.name}</CardTitle>
          </div>
          {onClose && (
            <Button variant="ghost" size="icon" onClick={onClose} className="h-6 w-6">
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
        <p className="text-xs text-muted-foreground mt-1">ID: {node.id}</p>
      </CardHeader>
      <CardContent className="px-4 pb-3">
        {/* Проблемы */}
        {node.criticalIssues > 0 && (
          <div className="mb-3 p-2 bg-red-50 dark:bg-red-900/30 rounded border border-red-200 dark:border-red-800">
            <div className="flex items-center gap-1.5 text-red-600 dark:text-red-400 text-xs font-medium">
              <AlertTriangle className="h-3.5 w-3.5" />
              {node.criticalIssues} критических проблем
            </div>
          </div>
        )}

        {/* Параметры устройства */}
        {mainDevice && (
          <div className="space-y-2">
            {/* Электрические параметры */}
            <div className="grid grid-cols-2 gap-2">
              {mainDevice.currentNom && (
                <div className="p-2 bg-slate-50 dark:bg-slate-700/50 rounded">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Gauge className="h-3 w-3" />
                    Iном
                  </div>
                  <div className="font-medium">{mainDevice.currentNom} А</div>
                </div>
              )}
              {mainDevice.pKw && (
                <div className="p-2 bg-slate-50 dark:bg-slate-700/50 rounded">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Zap className="h-3 w-3" />
                    P
                  </div>
                  <div className="font-medium">{mainDevice.pKw} кВт</div>
                </div>
              )}
              {mainDevice.qKvar && (
                <div className="p-2 bg-slate-50 dark:bg-slate-700/50 rounded">
                  <div className="text-xs text-muted-foreground">Q</div>
                  <div className="font-medium">{mainDevice.qKvar} квар</div>
                </div>
              )}
              {mainDevice.cosPhi && (
                <div className="p-2 bg-slate-50 dark:bg-slate-700/50 rounded">
                  <div className="text-xs text-muted-foreground">cos φ</div>
                  <div className="font-medium">{mainDevice.cosPhi.toFixed(2)}</div>
                </div>
              )}
              {mainDevice.sKva && (
                <div className="p-2 bg-slate-50 dark:bg-slate-700/50 rounded">
                  <div className="text-xs text-muted-foreground">S</div>
                  <div className="font-medium">{mainDevice.sKva} кВА</div>
                </div>
              )}
              {mainDevice.model && (
                <div className="p-2 bg-slate-50 dark:bg-slate-700/50 rounded">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Settings className="h-3 w-3" />
                    Модель
                  </div>
                  <div className="font-medium text-sm">{mainDevice.model}</div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Результаты валидации */}
        {node.validationResults && node.validationResults.length > 0 && (
          <div className="mt-3">
            <div className="text-xs font-medium text-muted-foreground mb-2">
              Результаты проверки
            </div>
            <div className="space-y-1.5">
              {node.validationResults.slice(0, 3).map((result, idx) => (
                <div
                  key={idx}
                  className={`p-2 rounded text-xs ${
                    result.status === 'CRITICAL' 
                      ? 'bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-400'
                      : result.status === 'FAIL'
                      ? 'bg-orange-50 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400'
                      : result.status === 'WARN'
                      ? 'bg-yellow-50 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400'
                      : 'bg-green-50 dark:bg-green-900/30 text-green-700 dark:text-green-400'
                  }`}
                >
                  {result.message}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Связанные устройства */}
        {node.devices && node.devices.length > 1 && (
          <div className="mt-3">
            <div className="text-xs font-medium text-muted-foreground mb-2">
              Устройства ({node.devices.length})
            </div>
            <div className="flex flex-wrap gap-1">
              {node.devices.slice(1, 5).map((device, idx) => (
                <Badge key={idx} variant="outline" className="text-xs">
                  {device.type}: {device.model || device.id}
                </Badge>
              ))}
              {node.devices.length > 5 && (
                <Badge variant="outline" className="text-xs">
                  +{node.devices.length - 5}
                </Badge>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
