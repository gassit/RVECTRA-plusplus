'use client';

import { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { ZoomIn, ZoomOut, Maximize2, Zap } from 'lucide-react';
import type { GraphData, GraphNode, GraphEdge } from '@/types';

interface NetworkGraphProps {
  data: GraphData | null;
  onNodeClick?: (nodeId: string) => void;
  selectedNodeId?: string | null;
}

// Цвета узлов по типам
const NODE_COLORS: Record<string, { bg: string; border: string; text: string; darkBg: string; darkBorder: string }> = {
  SOURCE: { 
    bg: 'bg-emerald-100', border: 'border-emerald-500', text: 'text-emerald-700',
    darkBg: 'bg-emerald-900', darkBorder: 'border-emerald-400', 
  },
  CABINET: { 
    bg: 'bg-blue-100', border: 'border-blue-500', text: 'text-blue-700',
    darkBg: 'bg-blue-900', darkBorder: 'border-blue-400',
  },
  LOAD: { 
    bg: 'bg-orange-100', border: 'border-orange-500', text: 'text-orange-700',
    darkBg: 'bg-orange-900', darkBorder: 'border-orange-400',
  },
  BREAKER: { 
    bg: 'bg-slate-100', border: 'border-slate-500', text: 'text-slate-700',
    darkBg: 'bg-slate-700', darkBorder: 'border-slate-400',
  },
  BUS: { 
    bg: 'bg-purple-100', border: 'border-purple-500', text: 'text-purple-700',
    darkBg: 'bg-purple-900', darkBorder: 'border-purple-400',
  },
  METER: { 
    bg: 'bg-cyan-100', border: 'border-cyan-500', text: 'text-cyan-700',
    darkBg: 'bg-cyan-900', darkBorder: 'border-cyan-400',
  },
};

// Названия типов на русском
const TYPE_NAMES: Record<string, string> = {
  SOURCE: 'Ист.',
  CABINET: 'Шкаф',
  LOAD: 'Нагр.',
  BREAKER: 'Выкл.',
  BUS: 'Шина',
  METER: 'Счётч.',
};

export default function NetworkGraph({ data, onNodeClick, selectedNodeId }: NetworkGraphProps) {
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');

  // Фильтрация узлов по поиску
  const filteredData = useMemo(() => {
    if (!data) return null;
    if (!searchTerm) return data;

    const searchLower = searchTerm.toLowerCase();
    const matchingNodes = data.nodes.filter(n => 
      n.name.toLowerCase().includes(searchLower) ||
      n.id.toLowerCase().includes(searchLower)
    );
    const matchingIds = new Set(matchingNodes.map(n => n.id));
    const matchingEdges = data.edges.filter(e => 
      matchingIds.has(e.source) || matchingIds.has(e.target)
    );

    return {
      nodes: matchingNodes,
      edges: matchingEdges,
    };
  }, [data, searchTerm]);

  // Вычисляем границы графа для масштабирования
  const bounds = useMemo(() => {
    if (!filteredData || filteredData.nodes.length === 0) {
      return {
        minX: 0, maxX: 1200, minY: 0, maxY: 800,
        width: 1200, height: 800,
      };
    }

    const padding = 150;
    let minX = Infinity, maxX = -Infinity;
    let minY = Infinity, maxY = -Infinity;

    filteredData.nodes.forEach(node => {
      if (node.posX < minX) minX = node.posX;
      if (node.posX > maxX) maxX = node.posX;
      if (node.posY < minY) minY = node.posY;
      if (node.posY > maxY) maxY = node.posY;
    });

    return {
      minX: minX - padding,
      maxX: maxX + padding,
      minY: minY - padding,
      maxY: maxY + padding,
      width: maxX - minX + padding * 2,
      height: maxY - minY + padding * 2,
    };
  }, [filteredData]);

  // Если данных нет
  if (!filteredData || filteredData.nodes.length === 0) {
    return (
      <div className="h-full flex items-center justify-center bg-white dark:bg-slate-800">
        <div className="text-center">
          <Zap className="h-12 w-12 mx-auto text-slate-300 dark:text-slate-600 mb-4" />
          <p className="text-muted-foreground">Нет данных для отображения</p>
          <p className="text-sm text-muted-foreground mt-1">Нажмите "Импорт" для загрузки данных</p>
        </div>
      </div>
    );
  }

  // Преобразуем координаты
  const transformX = (x: number) => x - bounds.minX;
  const transformY = (y: number) => y - bounds.minY;

  const svgWidth = Math.max(1200, bounds.width) * zoom;
  const svgHeight = Math.max(800, bounds.height) * zoom;

  return (
    <div className="h-full flex flex-col bg-white dark:bg-slate-800">
      {/* Панель управления */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
        {/* Поиск */}
        <Input
          placeholder="Поиск по названию или ID..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-xs h-8 text-sm"
        />

        {/* Легенда и зум */}
        <div className="flex items-center gap-4">
          {/* Легенда */}
          <div className="flex items-center gap-3 text-xs">
            {Object.entries(TYPE_NAMES).slice(0, 4).map(([type, name]) => (
              <div key={type} className="flex items-center gap-1">
                <div className={`w-3 h-3 rounded-sm ${NODE_COLORS[type]?.bg || 'bg-gray-100'} dark:${NODE_COLORS[type]?.darkBg || 'bg-gray-700'} border ${NODE_COLORS[type]?.border || 'border-gray-500'} dark:${NODE_COLORS[type]?.darkBorder}`} />
                <span className="text-muted-foreground">{name}</span>
              </div>
            ))}
          </div>

          {/* Зум */}
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setZoom(z => Math.max(0.25, z - 0.25))}
              className="h-7 w-7"
            >
              <ZoomOut className="h-3.5 w-3.5" />
            </Button>
            <span className="text-xs text-muted-foreground w-12 text-center">
              {Math.round(zoom * 100)}%
            </span>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setZoom(z => Math.min(2, z + 0.25))}
              className="h-7 w-7"
            >
              <ZoomIn className="h-3.5 w-3.5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setZoom(1)}
              className="h-7 w-7"
            >
              <Maximize2 className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </div>

      {/* SVG граф */}
      <ScrollArea className="flex-1">
        <svg
          width={svgWidth}
          height={svgHeight}
          className="bg-slate-50 dark:bg-slate-900"
        >
          <g transform={`scale(${zoom})`}>
            {/* Рёбра (связи) */}
            <g className="edges">
              {filteredData.edges.map(edge => {
                const sourceNode = filteredData.nodes.find(n => n.id === edge.source);
                const targetNode = filteredData.nodes.find(n => n.id === edge.target);
                if (!sourceNode || !targetNode) return null;

                const x1 = transformX(sourceNode.posX) + 50;
                const y1 = transformY(sourceNode.posY) + 20;
                const x2 = transformX(targetNode.posX) + 50;
                const y2 = transformY(targetNode.posY) + 20;

                return (
                  <g key={edge.id}>
                    <line
                      x1={x1}
                      y1={y1}
                      x2={x2}
                      y2={y2}
                      stroke="#94a3b8"
                      className="dark:stroke-slate-600"
                      strokeWidth={2}
                      strokeDasharray={edge.type === 'CABLE' ? 'none' : '5,5'}
                    />
                    {/* Подпись кабеля */}
                    {edge.wireType && edge.wireSize && (
                      <text
                        x={(x1 + x2) / 2}
                        y={(y1 + y2) / 2 - 8}
                        fontSize={9}
                        fill="#64748b"
                        className="dark:fill-slate-500"
                        textAnchor="middle"
                      >
                        {edge.wireType} {edge.wireSize}мм²
                        {edge.length && ` ${edge.length}м`}
                      </text>
                    )}
                  </g>
                );
              })}
            </g>

            {/* Узлы */}
            <g className="nodes">
              {filteredData.nodes.map(node => {
                const colors = NODE_COLORS[node.type] || NODE_COLORS.BREAKER;
                const x = transformX(node.posX);
                const y = transformY(node.posY);
                const isSelected = node.id === selectedNodeId;
                const isHovered = node.id === hoveredNode;
                const hasCritical = node.criticalIssues > 0;

                return (
                  <g
                    key={node.id}
                    transform={`translate(${x}, ${y})`}
                    onClick={() => onNodeClick?.(node.id)}
                    onMouseEnter={() => setHoveredNode(node.id)}
                    onMouseLeave={() => setHoveredNode(null)}
                    style={{ cursor: 'pointer' }}
                  >
                    {/* Фон узла */}
                    <rect
                      width={100}
                      height={40}
                      rx={6}
                      className={`${colors.bg} dark:${colors.darkBg} ${
                        hasCritical ? 'stroke-red-500 dark:stroke-red-400 stroke-2' : colors.border
                      } ${isSelected ? 'stroke-2 stroke-yellow-500 dark:stroke-yellow-400' : 'stroke'}`}
                      fill={hasCritical ? undefined : undefined}
                    />

                    {/* Иконка критической проблемы */}
                    {hasCritical && (
                      <circle cx={90} cy={10} r={8} fill="#ef4444" />
                    )}

                    {/* Текст */}
                    <text
                      x={50}
                      y={15}
                      fontSize={9}
                      fontWeight="bold"
                      className={`${colors.text} dark:text-slate-200`}
                      textAnchor="middle"
                    >
                      {TYPE_NAMES[node.type]}
                    </text>
                    <text
                      x={50}
                      y={28}
                      fontSize={8}
                      fill="#374151"
                      className="dark:fill-slate-300"
                      textAnchor="middle"
                    >
                      {node.name.length > 14 ? node.name.slice(0, 14) + '...' : node.name}
                    </text>
                  </g>
                );
              })}
            </g>
          </g>
        </svg>
      </ScrollArea>

      {/* Подсказка при наведении */}
      {hoveredNode && (
        <div className="absolute bottom-4 right-4 p-3 bg-white dark:bg-slate-800 rounded-lg shadow-lg border border-slate-200 dark:border-slate-700 text-sm">
          {(() => {
            const node = filteredData.nodes.find(n => n.id === hoveredNode);
            if (!node) return null;
            const device = node.devices?.[0];
            return (
              <div className="space-y-1">
                <div className="font-medium">{node.name}</div>
                <div className="text-xs text-muted-foreground">ID: {node.id}</div>
                {device?.currentNom && (
                  <div className="text-xs">Iном: {device.currentNom}А</div>
                )}
                {device?.pKw && (
                  <div className="text-xs">P: {device.pKw}кВт</div>
                )}
                {node.criticalIssues > 0 && (
                  <Badge variant="destructive" className="mt-1">
                    {node.criticalIssues} проблем
                  </Badge>
                )}
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
}
