// ============================================================================
// СЕРВИС ИМПОРТА ДАННЫХ ИЗ EXCEL
// ============================================================================

import * as XLSX from 'xlsx';
import * as fs from 'fs';
import * as path from 'path';
import { db } from '@/lib/db';
import {
  resetCounters,
  generateElementId,
  generateDeviceId,
  generateConnectionId,
} from '@/lib/utils/id-generator';
import { calculateCableImpedanceFromReference } from '@/lib/calculations/impedance';
import type { ImportResponse, ElementType, DeviceType } from '@/types';

// Путь к файлу импорта
const INPUT_FILE_PATH = '/home/z/my-project/upload/input.xlsx';

/**
 * Интерфейс строки из Excel
 */
interface ExcelRow {
  [key: string]: string | number | undefined;
}

/**
 * Парсинг Excel файла и импорт данных в БД
 */
export async function importFromExcel(): Promise<ImportResponse> {
  try {
    // Сбрасываем счётчики ID
    resetCounters();

    // Проверяем существование файла
    if (!fs.existsSync(INPUT_FILE_PATH)) {
      return {
        success: false,
        message: 'Файл input.xlsx не найден',
        imported: { elements: 0, devices: 0, connections: 0 },
        errors: ['Файл не найден: ' + INPUT_FILE_PATH],
      };
    }

    // Читаем Excel файл
    const fileBuffer = fs.readFileSync(INPUT_FILE_PATH);
    const workbook = XLSX.read(fileBuffer, { type: 'buffer' });
    const errors: string[] = [];
    let totalElements = 0;
    let totalDevices = 0;
    let totalConnections = 0;

    // Очищаем базу данных перед импортом
    await clearDatabase();

    // Обрабатываем каждый лист
    for (const sheetName of workbook.SheetNames) {
      const sheet = workbook.Sheets[sheetName];
      const rows: ExcelRow[] = XLSX.utils.sheet_to_json(sheet);

      console.log(`Processing sheet: ${sheetName}, rows: ${rows.length}`);

      try {
        switch (sheetName.toLowerCase()) {
          case 'источники':
          case 'sources':
            const sourceResult = await importSources(rows);
            totalElements += sourceResult.elements;
            totalDevices += sourceResult.devices;
            break;

          case 'шкафы':
          case 'cabinets':
            const cabinetResult = await importCabinets(rows);
            totalElements += cabinetResult.elements;
            totalDevices += cabinetResult.devices;
            break;

          case 'нагрузки':
          case 'loads':
            const loadResult = await importLoads(rows);
            totalElements += loadResult.elements;
            totalDevices += loadResult.devices;
            break;

          case 'выключатели':
          case 'breakers':
            const breakerResult = await importBreakers(rows);
            totalElements += breakerResult.elements;
            totalDevices += breakerResult.devices;
            break;

          case 'связи':
          case 'connections':
          case 'кабели':
          case 'cables':
            const connectionResult = await importConnections(rows);
            totalConnections += connectionResult.connections;
            break;

          default:
            // Пытаемся импортировать как общий формат
            const genericResult = await importGeneric(rows, sheetName);
            totalElements += genericResult.elements;
            totalDevices += genericResult.devices;
            totalConnections += genericResult.connections;
        }
      } catch (sheetError) {
        const errorMsg = `Ошибка обработки листа ${sheetName}: ${sheetError instanceof Error ? sheetError.message : String(sheetError)}`;
        console.error(errorMsg);
        errors.push(errorMsg);
      }
    }

    // Если данных нет, создаём демо-данные
    if (totalElements === 0) {
      const demoResult = await createDemoData();
      totalElements = demoResult.elements;
      totalDevices = demoResult.devices;
      totalConnections = demoResult.connections;
    }

    // Рассчитываем позиции для визуализации
    await calculateNodePositions();

    return {
      success: true,
      message: `Импорт завершён успешно`,
      imported: {
        elements: totalElements,
        devices: totalDevices,
        connections: totalConnections,
      },
      errors: errors.length > 0 ? errors : undefined,
    };
  } catch (error) {
    console.error('Import error:', error);
    return {
      success: false,
      message: 'Ошибка импорта',
      imported: { elements: 0, devices: 0, connections: 0 },
      errors: [error instanceof Error ? error.message : String(error)],
    };
  }
}

/**
 * Очистка базы данных
 */
async function clearDatabase(): Promise<void> {
  await db.validationResult.deleteMany();
  await db.measurement.deleteMany();
  await db.deviceState.deleteMany();
  await db.protection.deleteMany();
  await db.atsLogic.deleteMany();
  await db.command.deleteMany();
  await db.powerFlow.deleteMany();
  await db.shortCircuit.deleteMany();
  await db.network.deleteMany();
  await db.connection.deleteMany();
  await db.device.deleteMany();
  await db.element.deleteMany();
}

/**
 * Импорт источников
 */
async function importSources(rows: ExcelRow[]): Promise<{ elements: number; devices: number }> {
  let elements = 0;
  let devices = 0;

  for (const row of rows) {
    const name = String(row['Наименование'] || row['Название'] || row['Name'] || row['name'] || `Источник ${elements + 1}`);
    const voltage = Number(row['Напряжение'] || row['U'] || row['Напряжение кВ'] || 10);
    const power = Number(row['Мощность'] || row['S'] || row['Мощность кВА'] || 630);
    const code = String(row['Код'] || row['ID'] || '');

    const elementId = generateElementId('SOURCE', code);

    // Создаём элемент
    await db.element.create({
      data: {
        id: elementId,
        type: 'SOURCE',
        name: name,
        voltage_level: voltage,
        description: `Источник питания ${power} кВА`,
        pos_x: 0,
        pos_y: 0,
      },
    });
    elements++;

    // Создаём устройство
    const deviceId = generateDeviceId('SOURCE');
    await db.device.create({
      data: {
        id: deviceId,
        type: 'SOURCE',
        slot_id: elementId,
        voltage_nom: voltage * 1000,
        current_nom: power / (Math.sqrt(3) * voltage),
        s_kva: power,
      },
    });
    devices++;
  }

  return { elements, devices };
}

/**
 * Импорт шкафов
 */
async function importCabinets(rows: ExcelRow[]): Promise<{ elements: number; devices: number }> {
  let elements = 0;
  let devices = 0;

  for (const row of rows) {
    const name = String(row['Наименование'] || row['Название'] || row['Name'] || row['name'] || `Шкаф ${elements + 1}`);
    const location = String(row['Расположение'] || row['Помещение'] || '');
    const parentId = String(row['Родитель'] || row['Parent'] || '');

    const elementId = generateElementId('CABINET', undefined, name.replace(/\s+/g, '_').toUpperCase());

    await db.element.create({
      data: {
        id: elementId,
        type: 'CABINET',
        name: name,
        location: location || undefined,
        parent_id: parentId || undefined,
        voltage_level: 0.4,
        pos_x: 0,
        pos_y: 0,
      },
    });
    elements++;
  }

  return { elements, devices };
}

/**
 * Импорт нагрузок
 */
async function importLoads(rows: ExcelRow[]): Promise<{ elements: number; devices: number }> {
  let elements = 0;
  let devices = 0;

  for (const row of rows) {
    const name = String(row['Наименование'] || row['Название'] || row['Name'] || row['name'] || `Нагрузка ${elements + 1}`);
    const pKw = Number(row['P'] || row['Мощность'] || row['P кВт'] || 0);
    const qKvar = Number(row['Q'] || row['Реактивная'] || row['Q квар'] || 0);
    const cosPhi = Number(row['cosφ'] || row['КМ'] || row['cosPhi'] || 0.9);
    const parentId = String(row['Шкаф'] || row['Родитель'] || row['Parent'] || '');

    const elementId = generateElementId('LOAD');

    // Создаём элемент
    await db.element.create({
      data: {
        id: elementId,
        type: 'LOAD',
        name: name,
        parent_id: parentId || undefined,
        voltage_level: 0.4,
        pos_x: 0,
        pos_y: 0,
      },
    });
    elements++;

    // Создаём устройство нагрузки
    const deviceId = generateDeviceId('LOAD');
    const sKva = pKw / cosPhi;
    await db.device.create({
      data: {
        id: deviceId,
        type: 'LOAD',
        slot_id: elementId,
        p_kw: pKw,
        q_kvar: qKvar,
        s_kva: sKva,
        cos_phi: cosPhi,
        voltage_nom: 400,
      },
    });
    devices++;
  }

  return { elements, devices };
}

/**
 * Импорт выключателей
 */
async function importBreakers(rows: ExcelRow[]): Promise<{ elements: number; devices: number }> {
  let elements = 0;
  let devices = 0;

  for (const row of rows) {
    const name = String(row['Наименование'] || row['Название'] || row['Name'] || row['name'] || `Выкл ${elements + 1}`);
    const model = String(row['Модель'] || row['Тип'] || row['Model'] || 'ВА-47-29');
    const currentNom = Number(row['Iном'] || row['Ток'] || row['In'] || 16);
    const parentId = String(row['Шкаф'] || row['Родитель'] || row['Parent'] || '');
    const trippingChar = String(row['Характеристика'] || row['Char'] || 'C');

    const elementId = generateElementId('BREAKER', undefined, name.replace(/\s+/g, '_').toUpperCase());

    // Создаём элемент
    await db.element.create({
      data: {
        id: elementId,
        type: 'BREAKER',
        name: name,
        parent_id: parentId || undefined,
        voltage_level: 0.4,
        pos_x: 0,
        pos_y: 0,
      },
    });
    elements++;

    // Создаём устройство
    const deviceId = generateDeviceId('BREAKER');
    await db.device.create({
      data: {
        id: deviceId,
        type: 'BREAKER',
        slot_id: elementId,
        model: model,
        current_nom: currentNom,
        in_rating: currentNom,
        tripping_char: trippingChar,
        voltage_nom: 400,
        poles: 3,
      },
    });
    devices++;
  }

  return { elements, devices };
}

/**
 * Импорт связей
 */
async function importConnections(rows: ExcelRow[]): Promise<{ connections: number }> {
  let connections = 0;

  for (const row of rows) {
    const fromId = String(row['От'] || row['From'] || row['Начало'] || '');
    const toId = String(row['До'] || row['To'] || row['Конец'] || '');
    const wireType = String(row['Марка'] || row['Кабель'] || row['Type'] || 'ВВГ');
    const wireSize = Number(row['Сечение'] || row['Size'] || row['S мм2'] || 4);
    const length = Number(row['Длина'] || row['Length'] || row['L м'] || 10);
    const installationMethod = String(row['Прокладка'] || row['Method'] || 'in_air');

    if (!fromId || !toId) continue;

    // Проверяем существование элементов
    const fromExists = await db.element.findUnique({ where: { id: fromId } });
    const toExists = await db.element.findUnique({ where: { id: toId } });

    if (!fromExists || !toExists) {
      console.warn(`Elements not found for connection: ${fromId} -> ${toId}`);
      continue;
    }

    // Рассчитываем сопротивления
    const impedance = calculateCableImpedanceFromReference(length, wireType, wireSize);
    const connectionId = generateConnectionId(fromId, toId);

    await db.connection.create({
      data: {
        id: connectionId,
        from_id: fromId,
        to_id: toId,
        type: 'CABLE',
        length: length,
        wire_type: wireType,
        wire_size: wireSize,
        material: wireType.startsWith('А') ? 'Al' : 'Cu',
        resistance_r: impedance?.r,
        reactance_x: impedance?.x,
        impedance_z: impedance?.z,
        installation_method: installationMethod,
      },
    });
    connections++;
  }

  return { connections };
}

/**
 * Универсальный импорт (для общего формата)
 */
async function importGeneric(
  rows: ExcelRow[],
  sheetName: string
): Promise<{ elements: number; devices: number; connections: number }> {
  let elements = 0;
  let devices = 0;
  let connections = 0;

  // Определяем тип по наличию полей
  for (const row of rows) {
    const type = String(row['Тип'] || row['Type'] || '').toUpperCase();
    const fromId = String(row['От'] || row['From'] || '');
    const toId = String(row['До'] || row['To'] || '');

    // Если есть поля "От" и "До" - это связь
    if (fromId && toId) {
      const result = await importConnections([row]);
      connections += result.connections;
      continue;
    }

    // Иначе это элемент
    let elementType: ElementType = 'LOAD';
    let deviceType: DeviceType = 'LOAD';

    if (type.includes('ИСТОЧНИК') || type.includes('SOURCE') || type.includes('ТП')) {
      elementType = 'SOURCE';
      deviceType = 'SOURCE';
    } else if (type.includes('ШКАФ') || type.includes('CABINET') || type.includes('ЩИТ')) {
      elementType = 'CABINET';
    } else if (type.includes('ВЫКЛ') || type.includes('BREAKER') || type.includes('АВТ')) {
      elementType = 'BREAKER';
      deviceType = 'BREAKER';
    } else if (type.includes('НАГРУЗ') || type.includes('LOAD')) {
      elementType = 'LOAD';
      deviceType = 'LOAD';
    }

    const name = String(row['Наименование'] || row['Name'] || row['Название'] || `${elementType} ${elements + 1}`);

    const elementId = generateElementId(elementType);

    await db.element.create({
      data: {
        id: elementId,
        type: elementType,
        name: name,
        voltage_level: 0.4,
        pos_x: 0,
        pos_y: 0,
      },
    });
    elements++;

    // Создаём устройство если нужно
    if (deviceType === 'BREAKER' || deviceType === 'SOURCE' || deviceType === 'LOAD') {
      const currentNom = Number(row['Iном'] || row['In'] || 16);
      const pKw = Number(row['P'] || row['Мощность'] || 0);

      const deviceId = generateDeviceId(deviceType);
      await db.device.create({
        data: {
          id: deviceId,
          type: deviceType,
          slot_id: elementId,
          current_nom: currentNom || undefined,
          p_kw: pKw || undefined,
          voltage_nom: 400,
        },
      });
      devices++;
    }
  }

  return { elements, devices, connections };
}

/**
 * Создание демо-данных
 */
async function createDemoData(): Promise<{ elements: number; devices: number; connections: number }> {
  console.log('Creating demo data...');

  // Создаём источники
  const source1 = generateElementId('SOURCE', 'TP21');
  await db.element.create({
    data: {
      id: source1,
      type: 'SOURCE',
      name: 'ТП-21 Трансформатор 1',
      voltage_level: 0.4,
      description: 'ТМ-630/10, 630 кВА',
      pos_x: 100,
      pos_y: 100,
    },
  });

  const deviceId1 = generateDeviceId('SOURCE');
  await db.device.create({
    data: {
      id: deviceId1,
      type: 'SOURCE',
      slot_id: source1,
      voltage_nom: 400,
      current_nom: 910,
      s_kva: 630,
    },
  });

  // Создаём главный шкаф
  const grSch = generateElementId('CABINET', undefined, 'GRSCH1');
  await db.element.create({
    data: {
      id: grSch,
      type: 'CABINET',
      name: 'ГРЩ-1',
      voltage_level: 0.4,
      description: 'Главный распределительный щит',
      pos_x: 300,
      pos_y: 100,
    },
  });

  // Выключатель ввода
  const qf1 = generateElementId('BREAKER', undefined, 'GRSCH1_IN');
  await db.element.create({
    data: {
      id: qf1,
      type: 'BREAKER',
      name: 'QF1 Вводной',
      parent_id: grSch,
      voltage_level: 0.4,
      pos_x: 350,
      pos_y: 100,
    },
  });

  const devQf1 = generateDeviceId('BREAKER');
  await db.device.create({
    data: {
      id: devQf1,
      type: 'BREAKER',
      slot_id: qf1,
      model: 'ВА-55-41',
      current_nom: 630,
      in_rating: 630,
      voltage_nom: 400,
      poles: 3,
    },
  });

  // Распределительные шкафы
  const sch1 = generateElementId('CABINET', undefined, 'SCH1');
  await db.element.create({
    data: {
      id: sch1,
      type: 'CABINET',
      name: 'ЩР-1',
      voltage_level: 0.4,
      description: 'Щит распределительный 1',
      pos_x: 500,
      pos_y: 50,
    },
  });

  const sch2 = generateElementId('CABINET', undefined, 'SCH2');
  await db.element.create({
    data: {
      id: sch2,
      type: 'CABINET',
      name: 'ЩР-2',
      voltage_level: 0.4,
      description: 'Щит распределительный 2',
      pos_x: 500,
      pos_y: 150,
    },
  });

  // Выключатели отходящих линий
  const qf2 = generateElementId('BREAKER', undefined, 'GRSCH1_01');
  await db.element.create({
    data: {
      id: qf2,
      type: 'BREAKER',
      name: 'QF2 Линия 1',
      parent_id: grSch,
      voltage_level: 0.4,
      pos_x: 380,
      pos_y: 70,
    },
  });

  const devQf2 = generateDeviceId('BREAKER');
  await db.device.create({
    data: {
      id: devQf2,
      type: 'BREAKER',
      slot_id: qf2,
      model: 'ВА-47-29',
      current_nom: 63,
      in_rating: 63,
      tripping_char: 'C',
      voltage_nom: 400,
      poles: 3,
    },
  });

  const qf3 = generateElementId('BREAKER', undefined, 'GRSCH1_02');
  await db.element.create({
    data: {
      id: qf3,
      type: 'BREAKER',
      name: 'QF3 Линия 2',
      parent_id: grSch,
      voltage_level: 0.4,
      pos_x: 380,
      pos_y: 130,
    },
  });

  const devQf3 = generateDeviceId('BREAKER');
  await db.device.create({
    data: {
      id: devQf3,
      type: 'BREAKER',
      slot_id: qf3,
      model: 'ВА-47-29',
      current_nom: 32,
      in_rating: 32,
      tripping_char: 'C',
      voltage_nom: 400,
      poles: 3,
    },
  });

  // Нагрузки
  const load1 = generateElementId('LOAD');
  await db.element.create({
    data: {
      id: load1,
      type: 'LOAD',
      name: 'Освещение цех 1',
      parent_id: sch1,
      voltage_level: 0.4,
      pos_x: 700,
      pos_y: 50,
    },
  });

  const devL1 = generateDeviceId('LOAD');
  await db.device.create({
    data: {
      id: devL1,
      type: 'LOAD',
      slot_id: load1,
      p_kw: 15,
      q_kvar: 5,
      s_kva: 15.8,
      cos_phi: 0.95,
      voltage_nom: 400,
    },
  });

  const load2 = generateElementId('LOAD');
  await db.element.create({
    data: {
      id: load2,
      type: 'LOAD',
      name: 'Розеточная группа',
      parent_id: sch2,
      voltage_level: 0.4,
      pos_x: 700,
      pos_y: 150,
    },
  });

  const devL2 = generateDeviceId('LOAD');
  await db.device.create({
    data: {
      id: devL2,
      type: 'LOAD',
      slot_id: load2,
      p_kw: 8,
      q_kvar: 3,
      s_kva: 8.5,
      cos_phi: 0.94,
      voltage_nom: 400,
    },
  });

  // Связи
  // Источник -> ГРЩ
  await db.connection.create({
    data: {
      id: generateConnectionId(source1, grSch),
      from_id: source1,
      to_id: grSch,
      type: 'CABLE',
      length: 25,
      wire_type: 'ВВГ',
      wire_size: 120,
      material: 'Cu',
      resistance_r: 0.0038,
      reactance_x: 0.0018,
      impedance_z: 0.0042,
      installation_method: 'in_ground',
    },
  });

  // ГРЩ -> ЩР1
  await db.connection.create({
    data: {
      id: generateConnectionId(grSch, sch1),
      from_id: grSch,
      to_id: sch1,
      type: 'CABLE',
      length: 45,
      wire_type: 'ВВГ',
      wire_size: 16,
      material: 'Cu',
      resistance_r: 0.052,
      reactance_x: 0.0036,
      impedance_z: 0.052,
      installation_method: 'in_air',
    },
  });

  // ГРЩ -> ЩР2
  await db.connection.create({
    data: {
      id: generateConnectionId(grSch, sch2),
      from_id: grSch,
      to_id: sch2,
      type: 'CABLE',
      length: 30,
      wire_type: 'ВВГ',
      wire_size: 6,
      material: 'Cu',
      resistance_r: 0.092,
      reactance_x: 0.0026,
      impedance_z: 0.092,
      installation_method: 'in_air',
    },
  });

  // ЩР1 -> Нагрузка1
  await db.connection.create({
    data: {
      id: generateConnectionId(sch1, load1),
      from_id: sch1,
      to_id: load1,
      type: 'CABLE',
      length: 20,
      wire_type: 'ВВГ',
      wire_size: 4,
      material: 'Cu',
      resistance_r: 0.092,
      reactance_x: 0.0018,
      impedance_z: 0.092,
      installation_method: 'in_air',
    },
  });

  // ЩР2 -> Нагрузка2
  await db.connection.create({
    data: {
      id: generateConnectionId(sch2, load2),
      from_id: sch2,
      to_id: load2,
      type: 'CABLE',
      length: 15,
      wire_type: 'ВВГ',
      wire_size: 2.5,
      material: 'Cu',
      resistance_r: 0.111,
      reactance_x: 0.0014,
      impedance_z: 0.111,
      installation_method: 'in_air',
    },
  });

  return { elements: 8, devices: 6, connections: 5 };
}

/**
 * Расчёт позиций узлов для визуализации
 */
async function calculateNodePositions(): Promise<void> {
  const elements = await db.element.findMany({
    orderBy: { created_at: 'asc' },
  });

  const typeGroups: Record<string, typeof elements> = {
    SOURCE: [],
    CABINET: [],
    BREAKER: [],
    LOAD: [],
  };

  // Группируем по типам
  for (const el of elements) {
    if (typeGroups[el.type]) {
      typeGroups[el.type].push(el);
    }
  }

  // Располагаем по уровням слева направо
  const positions: Record<string, { x: number; y: number }> = {};
  
  // Источники - левая колонка
  typeGroups.SOURCE.forEach((el, i) => {
    positions[el.id] = { x: 100, y: 100 + i * 150 };
  });

  // Главные шкафы и выключатели
  typeGroups.CABINET.forEach((el, i) => {
    positions[el.id] = { x: 300 + i * 200, y: 150 };
  });

  // Выключатели - рядом со шкафами
  typeGroups.BREAKER.forEach((el, i) => {
    const parent = elements.find(e => e.id === el.parent_id);
    if (parent && positions[parent.id]) {
      positions[el.id] = {
        x: positions[parent.id].x + 30,
        y: positions[parent.id].y + (i % 2 === 0 ? -30 : 30),
      };
    } else {
      positions[el.id] = { x: 350 + i * 100, y: 200 + i * 50 };
    }
  });

  // Нагрузки - правая колонка
  typeGroups.LOAD.forEach((el, i) => {
    positions[el.id] = { x: 600, y: 100 + i * 100 };
  });

  // Обновляем позиции в БД
  for (const [id, pos] of Object.entries(positions)) {
    await db.element.update({
      where: { id },
      data: { pos_x: pos.x, pos_y: pos.y },
    });
  }
}

export default {
  importFromExcel,
};
